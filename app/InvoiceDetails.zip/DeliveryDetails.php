<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;

class DeliveryDetails extends Model {

    protected $primaryKey = 'id';
    protected $table = 'delivery_details';
    public $timestamps = false;

    

}
