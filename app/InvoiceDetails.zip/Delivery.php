<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;

class Delivery extends Model {

    protected $primaryKey = 'id';
    protected $table = 'delivery';
    public $timestamps = false;

    

}
